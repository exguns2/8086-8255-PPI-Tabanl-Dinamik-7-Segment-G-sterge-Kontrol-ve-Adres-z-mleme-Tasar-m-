STAK    SEGMENT PARA STACK 'STACK'
        DW 64 DUP(?)
STAK    ENDS

DATA    SEGMENT PARA 'DATA'
    GIRIS_ADR  EQU 04C8H
    CIKIS_ADR  EQU 04C9H

    LED_DURUM  DB 0CH
    MOD_SAG    DB 0
    MOD_SOL    DB 0
DATA    ENDS

CODE    SEGMENT PARA 'CODE'
        ASSUME CS:CODE, DS:DATA, SS:STAK

START:
        MOV AX, DATA
        MOV DS, AX

        ; Ilk degeri LED'lere gonder
        MOV AL, LED_DURUM
        MOV DX, CIKIS_ADR
        OUT DX, AL

ANA_DONGU:
        CALL BUTON_KONTROL
        CALL KAYDIRMA_ISLEMI
        CALL GECIKME
        JMP ANA_DONGU

; A: bit0 -> SOLA toggle
; B: bit7 -> SAGA toggle
BUTON_KONTROL PROC NEAR
        MOV DX, GIRIS_ADR
        IN  AL, DX

        ; A (bit0) - SOLA
        TEST AL, 01H
        JNZ  BK_KONTROL_B
        MOV MOD_SAG, 0
        XOR MOD_SOL, 1
        CALL BUTON_BEKLE

BK_KONTROL_B:
        ; B (bit7) - SAGA
        TEST AL, 80H
        JNZ  BK_BITIR
        MOV MOD_SOL, 0
        XOR MOD_SAG, 1
        CALL BUTON_BEKLE

BK_BITIR:
        RET
BUTON_KONTROL ENDP

KAYDIRMA_ISLEMI PROC NEAR
        CMP MOD_SAG, 1
        JE  KI_SAGA
        CMP MOD_SOL, 1
        JE  KI_SOLA
        RET

KI_SAGA:
        ROR LED_DURUM, 1
        JMP KI_GUNCELLE

KI_SOLA:
        ROL LED_DURUM, 1

KI_GUNCELLE:
        MOV AL, LED_DURUM
        MOV DX, CIKIS_ADR
        OUT DX, AL
        RET
KAYDIRMA_ISLEMI ENDP

; Bit0 ve Bit7 ikisi de 1 olana kadar bekle
BUTON_BEKLE PROC NEAR
BB_WAIT:
        IN  AL, DX
        AND AL, 081H
        CMP AL, 081H
        JNE BB_WAIT
        RET
BUTON_BEKLE ENDP

GECIKME PROC NEAR
        MOV CX, 0FFFFH
G1:     LOOP G1
        RET
GECIKME ENDP

CODE    ENDS
        END START