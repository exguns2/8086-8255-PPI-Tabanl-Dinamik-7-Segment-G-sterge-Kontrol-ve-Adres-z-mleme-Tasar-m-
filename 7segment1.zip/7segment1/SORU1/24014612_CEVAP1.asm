STAK    SEGMENT PARA STACK 'STACK'
        DW 64 DUP(?)
STAK    ENDS

DATA    SEGMENT PARA 'DATA'

DIGITS      DB 0C0H, 0F9H, 0A4H, 0B0H, 099H, 092H, 082H, 0F8H, 080H, 098H
GOS_VALUES  DB 0, 0, 0, 0
SECILI_GOS  DB 0FFH

PORTA       EQU 17E8H
PORTB       EQU 17EAH
PORTC       EQU 17ECH
KONTROL     EQU 17EEH

DATA    ENDS

CODE    SEGMENT PARA 'CODE'
        ASSUME CS:CODE, DS:DATA, SS:STAK

START:
        MOV AX, DATA
        MOV DS, AX

        MOV DX, KONTROL
        MOV AL, 90H
        OUT DX, AL

        MOV BYTE PTR GOS_VALUES,   0
        MOV BYTE PTR GOS_VALUES+1, 0
        MOV BYTE PTR GOS_VALUES+2, 0
        MOV BYTE PTR GOS_VALUES+3, 0
        MOV BYTE PTR SECILI_GOS,   0FFH

ANA_DONGU:
        CALL TARA_4
        CALL BUTON_ISLE
        JMP ANA_DONGU

TARA_4 PROC NEAR
        PUSH AX
        PUSH BX

        MOV BX, 0
        CALL BASAMAK
        MOV BX, 1
        CALL BASAMAK
        MOV BX, 2
        CALL BASAMAK
        MOV BX, 3
        CALL BASAMAK

        POP BX
        POP AX
        RET
TARA_4 ENDP

BASAMAK PROC NEAR
        PUSH AX
        PUSH CX
        PUSH DX
        PUSH SI

        MOV DX, PORTC
        MOV AL, 0
        OUT DX, AL

        LEA SI, GOS_VALUES
        MOV AL, [SI+BX]

        XOR AH, AH
        LEA SI, DIGITS
        ADD SI, AX
        MOV AL, [SI]

        MOV DX, PORTB
        OUT DX, AL

        MOV CL, BL
        MOV AL, 1
        SHL AL, CL
        MOV DX, PORTC
        OUT DX, AL

        MOV CX, 0150H
DLY:    LOOP DLY

        MOV DX, PORTC
        MOV AL, 0
        OUT DX, AL

        POP SI
        POP DX
        POP CX
        POP AX
        RET
BASAMAK ENDP

BUTON_ISLE PROC NEAR
        PUSH AX
        PUSH BX
        PUSH DX
        PUSH SI

        MOV DX, PORTA
        IN  AL, DX

        TEST AL, 01H
        JNZ  KONTROL_ARTTIR

        CALL BEKLE_BIRAK
        MOV AL, SECILI_GOS
        INC AL
        CMP AL, 4
        JB  SOK
        MOV AL, 0
SOK:    MOV SECILI_GOS, AL
        JMP CIK

KONTROL_ARTTIR:
        TEST AL, 04H
        JNZ  KONTROL_AZALT

        CALL BEKLE_BIRAK
        LEA SI, GOS_VALUES
        MOV BL, SECILI_GOS
        XOR BH, BH
        MOV AL, [SI+BX]
        INC AL
        CMP AL, 10
        JB  AOK
        MOV AL, 0
AOK:    MOV [SI+BX], AL
        JMP CIK

KONTROL_AZALT:
        TEST AL, 08H
        JNZ  CIK

        CALL BEKLE_BIRAK
        LEA SI, GOS_VALUES
        MOV BL, SECILI_GOS
        XOR BH, BH
        MOV AL, [SI+BX]
        CMP AL, 0
        JNE ZOK
        MOV AL, 10
ZOK:    DEC AL
        MOV [SI+BX], AL

CIK:
        POP SI
        POP DX
        POP BX
        POP AX
        RET
BUTON_ISLE ENDP

BEKLE_BIRAK PROC NEAR
        PUSH AX
        PUSH DX

WB:
        CALL TARA_4
        MOV DX, PORTA
        IN  AL, DX
        AND AL, 0DH
        CMP AL, 0DH
        JNE WB

        POP DX
        POP AX
        RET
BEKLE_BIRAK ENDP

CODE    ENDS
        END START